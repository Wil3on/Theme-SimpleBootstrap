$(document).ready(function() {
        $('.main [href="?m=mysql&p=mysql_admin"]').addClass('btn').addClass('btn-sm').addClass('btn-primary');

});
