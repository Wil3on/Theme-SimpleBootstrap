$(document).ready(function(){
	$('.main').addClass('main-content').parent().attr('id', 'content');
});
