$(document).ready(function() {
        $('.main [href^="?m=gamemanager&p=game_monitor&home_id-mod_id-ip-port="]').addClass('btn').addClass('btn-sm').addClass('btn-primary');

});
