$(document).ready(function() {
        $('.main [href="?m=server"]').addClass('btn').addClass('btn-sm').addClass('btn-primary');
});
