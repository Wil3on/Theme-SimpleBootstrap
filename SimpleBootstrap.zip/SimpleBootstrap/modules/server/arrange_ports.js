$(document).ready(function() {
        $('.main [href^="?m=server&p=edit&rhost_id"]').addClass('btn').addClass('btn-sm').addClass('btn-primary');


        $('[name="delete_range"]').removeClass('btn-primary').addClass('btn-danger');
});
