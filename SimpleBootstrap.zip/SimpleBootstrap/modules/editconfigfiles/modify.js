$(document).ready(function(){
	$('.main [href^="?m=editconfigfiles"]').addClass('btn').addClass('btn-primary').addClass('btn-xs');
});

