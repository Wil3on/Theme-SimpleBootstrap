$(document).ready(function() {
	$('.main > p:first-of-type').css("background-color", "").css("color", "");
	$('p > [href="?m=register&p=form"], p > [href="index.php"]').addClass('btn').addClass('btn-xs').addClass('btn-primary');
});
