$(document).ready(function() {
	$('.main > style:nth-child(2)').remove();
});

