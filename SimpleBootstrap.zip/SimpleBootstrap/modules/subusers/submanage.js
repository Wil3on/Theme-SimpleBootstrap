$(document).ready(function() {
        $('.main [href="?m=subusers&p=add"]').addClass('btn').addClass('btn-sm').addClass('btn-primary');
        $('.main [href="?m=subusers&p=del"]').addClass('btn').addClass('btn-sm').addClass('btn-danger');
});

