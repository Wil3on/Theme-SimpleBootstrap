$(document).ready(function() {
	$('p > a').addClass('btn').addClass('btn-primary').addClass('btn-sm');

});

