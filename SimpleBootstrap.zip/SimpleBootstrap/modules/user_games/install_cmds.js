$(document).ready(function() {
        $('.main [href^="?m=user_games&p=edit&home_id="]').addClass('btn').addClass('btn-primary').addClass('btn-sm');

});
