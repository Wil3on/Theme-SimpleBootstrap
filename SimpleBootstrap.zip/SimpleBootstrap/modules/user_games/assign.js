$(document).ready(function() {
	$('.main [href="?m=user_admin&p=show_groups"], .main [href="?m=user_admin"]').addClass('btn').addClass('btn-sm').addClass('btn-primary');
});
